﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FinalProyect
{
    public partial class Search : Form
    {
        static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=disadb;UID=root;PASSWORD=;";
        MySqlConnection con = new MySqlConnection(conexion);


        public Search()
        {
            InitializeComponent();
        }

        private void Search_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                //MessageBox.Show("Conexion Exitosa");
                con.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Conexion Fallida");
            }

            listmostrar_registros.View = View.Details;
            listmostrar_registros.FullRowSelect = true;
            listmostrar_registros.GridLines = true;

            listmostrar_registros.Columns.Add("Producto", 120);
            listmostrar_registros.Columns.Add("Tipo", 120);
            listmostrar_registros.Columns.Add("Precio", 80);
            listmostrar_registros.Columns.Add("SKU", 0);

            Cuenta.View = View.Details;
            Cuenta.FullRowSelect = true;
            Cuenta.GridLines = true;

            
            Cuenta.Columns.Add("Producto", 120);
            Cuenta.Columns.Add("Tipo", 120);
            Cuenta.Columns.Add("Precio", 80);
            Cuenta.Columns.Add("SKU", 50);

        }

        private void txtbusqueda_TextChanged(object sender, EventArgs e)
        {
            listmostrar_registros.Items.Clear();
            MySqlDataReader lector_datos;
            String buscar_sentenciaSQL = "SELECT * FROM productos WHERE Nombre LIKE'" + txtbusqueda.Text + "%'"; ;
            MySqlCommand buscar_comandoSQL = new MySqlCommand(buscar_sentenciaSQL, con);

            try
            {
                con.Open();
                lector_datos = buscar_comandoSQL.ExecuteReader();


                if (lector_datos.HasRows == true) //MOSTRAR REGISTROS
                {
                    while (lector_datos.Read())
                    {

                        ListViewItem lista = new ListViewItem(lector_datos["Nombre"].ToString());
                        lista.SubItems.Add(lector_datos["Tipo"].ToString());
                        lista.SubItems.Add(lector_datos["PrecioV"].ToString());             //BUSQUEDA APROXIMADA
                        lista.SubItems.Add(lector_datos["SKU"].ToString());

                        listmostrar_registros.Items.Add(lista); //Observar la lista de productos
                    }
                }
                else
                {
                    MessageBox.Show("No se han encontrado datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                lector_datos.Close();

                if (txtbusqueda.Text == String.Empty)
                {
                    listmostrar_registros.Items.Clear();
                }
                con.Close();

            }
            catch (Exception error)
            {
                MessageBox.Show("¡OCURRIO UN ERROR!---" + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        float final = 0;
        private void calcular()
        {
            float art = 0, total = 0;
            foreach (ListViewItem row in Cuenta.Items)
            {
                string precio = row.SubItems[3].Text;
                string arti = row.SubItems[0].Text;
                total += float.Parse(precio);

                if (float.Parse(arti) < 1)
                {
                    art += 1;
                }
                else
                {
                    art += float.Parse(arti);
                }

                final = final + (float.Parse(precio) * float.Parse(arti));


            }
            vender.Enabled = true;
            costtol.Text = "Total: $" + final.ToString();
            Artcant.Text = "Total de articulos: " + art.ToString();

        }




        private void listmostrar_registros_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listmostrar_registros.SelectedItems.Count > 0)
            {
                ListViewItem item = new ListViewItem(canti.Text);//1
                item.SubItems.Add(listmostrar_registros.SelectedItems[0].SubItems[0].Text);
                item.SubItems.Add(listmostrar_registros.SelectedItems[0].SubItems[1].Text);
                item.SubItems.Add(listmostrar_registros.SelectedItems[0].SubItems[2].Text);
                item.SubItems.Add(listmostrar_registros.SelectedItems[0].SubItems[3].Text);

                Cuenta.Items.Add(item);

                MessageBox.Show(item.SubItems[3].Text);
            }
            
        }

        private void calc_Click(object sender, EventArgs e)
        {
            calcular();
        }

        private void vender_Click(object sender, EventArgs e)
        {

            if (vender.Text.All(char.IsDigit))
            {
                vender.Text = "";
                errorProvider1.SetError(vender, "Solo puede ingresar el monto con el que el cliente pagará");
            }
            else
            {
                if (dinero.Text == String.Empty)
                {
                    MessageBox.Show("No se olvide de ingresar con cuanto pagará el cliente!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    string cash = dinero.Text;
                    float cambio = float.Parse(cash) - final;
                    errorProvider1.SetError(vender, "");
                    if (cambio < 0)
                    {
                        MessageBox.Show("No podemos cerrar trato si al cliente le falta dinero para pagar:(", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("El cambio del cliente es de $" + cambio.ToString(), "Buena venta!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        foreach (ListViewItem row in Cuenta.Items)
                        {
                            MessageBox.Show(row.SubItems[3].Text);
                        }
                    }
                }
                dinero.Text = "";
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Form ventanaDash = new Dashboard();
            ventanaDash.Show();
            this.Close();
        }

        private void dinero_TextChanged(object sender, EventArgs e)
        {
            if (dinero.Text.All(char.IsDigit))
            {
                errorProvider1.SetError(dinero, "");
            }
            else
            {
                errorProvider1.SetError(dinero, "No puede poner letras en este campo:(");
                dinero.Text = "";
            }
        }
    }
}
