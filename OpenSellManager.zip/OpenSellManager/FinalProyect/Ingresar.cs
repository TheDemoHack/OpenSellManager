﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FinalProyect
{

    public partial class Ingresar : Form
    {
        static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=disadb;UID=root;PASSWORD=;";
        MySqlConnection con = new MySqlConnection(conexion);

        public Ingresar()
        {
            InitializeComponent();
        }


        private void Ingresar_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                //MessageBox.Show("Conexion Exitosa");
                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show("¡OCURRIO UN ERROR! Contacte a soporte---" + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form ventanaDash = new Dashboard();
            ventanaDash.Show();
            this.Close();
        }
        
        private void BtnEnviar_Click(object sender, EventArgs e)
        {
            //comprobacion de llenado
            int ok = 0;
            //txtsku
            if (TxtSKU.Text.Trim() != string.Empty && TxtSKU.Text.All(char.IsLetterOrDigit))
            {

                errorProvider1.SetError(TxtSKU, "");
                ok++;
            }
            else
            {
                errorProvider1.SetError(TxtSKU, "Por favor, llene este campo");
                ok--;
            }
            //txtproducto
            if (TxtProducto.Text.Trim() != string.Empty && !(TxtProducto.Text.All(char.IsDigit)))
            {

                errorProvider1.SetError(TxtProducto, "");
                ok++;
            }
            else
            {
                errorProvider1.SetError(TxtProducto, "Llene este campo solo con letras o llenelo");
                ok--;
            }
            //txt precio
            if (TxtPrecio.Text.Trim() != string.Empty && !(TxtPrecio.Text.All(char.IsLetter)))
            {
                errorProvider1.SetError(TxtPrecio, "");
                ok++;
            }
            else
            {
                TxtPrecio.Text = string.Empty;
                errorProvider1.SetError(TxtPrecio, "Llene este campo solo con numeros o llenelo");
                ok--;
            }
            //txtcantidad
            if (TxtCantidad.Text.Trim() != string.Empty && TxtCantidad.Text.All(char.IsDigit))
            {

                errorProvider1.SetError(TxtCantidad, "");
                ok++;
            }
            else
            {
                errorProvider1.SetError(TxtCantidad, "Llene este campo solo con numeros o llenelo");
                ok--;
            }
            //txttipo
            if (TxtTipo.Text.Trim() != string.Empty && !(TxtProducto.Text.All(char.IsDigit)))
            {

                errorProvider1.SetError(TxtTipo, "");
                ok++;
            }
            else
            {
                errorProvider1.SetError(TxtTipo, "Llene este campo solo con letras o llenelo");
                ok--;
            }

            if (ok == 5)//si todo esta ok, procedemos a enviar 
            {
                string precio = TxtPrecio.Text;
                double PrecioC = float.Parse(precio);
                double PrecioV = PrecioC + (PrecioC * .16);
                PrecioV = PrecioV + (PrecioV * .30);

                string comandoSKU = "SELECT * FROM productos WHERE SKU='" + TxtSKU.Text + "';";
                string ComandoIn = "INSERT INTO `productos`(`SKU`, `Nombre`, `PrecioC`, `PrecioV`, `Cantidad`, `Tipo`) VALUES  ('" + TxtSKU.Text + "', '" + TxtProducto.Text + "', '" + TxtPrecio.Text + "', '" + PrecioV + "', '" + TxtCantidad.Text + "', '" + TxtTipo.Text + "');";
                
                con.Open();
                MySqlCommand comandosku = new MySqlCommand(comandoSKU, con);
                MySqlDataReader lectSKU = comandosku.ExecuteReader();
                Boolean LectSKU = lectSKU.Read();
                con.Close();
                TxtCantidad.Text = string.Empty;
                TxtPrecio.Text = string.Empty;
                TxtProducto.Text = string.Empty;
                TxtSKU.Text = string.Empty;
                TxtTipo.Text = string.Empty;

                if (LectSKU)
                {
                    MessageBox.Show("Parece que ya hay un articulo con ese SKU, favor de verificar o modificar", "Duplicidad de datos", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    try
                    {
                        con.Open();
                        MySqlCommand comandoCon = new MySqlCommand(ComandoIn, con);
                        lectSKU = comandoCon.ExecuteReader();
                        if (lectSKU.Read())
                        {
                            MessageBox.Show("algo salio mal:(");
                        }
                        else
                        {
                            MessageBox.Show("Producto agregado exitosamente!", "Correcto", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("¡OCURRIO UN ERROR! Contacte a soporte---" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                }
            }
            else
            {
                MessageBox.Show("Hay algunos errores, revise los campos", "error", MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
    }
}
