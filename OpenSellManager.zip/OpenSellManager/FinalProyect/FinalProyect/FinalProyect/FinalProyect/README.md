# FinalProyect
Proyecto final de programación III. sistema de automatización de biblioteca, apto para ser modificado para cualquier otro uso. se hace uso de una base de datos creada en access pero se pude ampliar a MySQL o similar
