﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FinalProyect
{
    public partial class Index : Form
    {
        static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=disadb;UID=root;PASSWORD=;";
        MySqlConnection con = new MySqlConnection(conexion);
        int contador;

        public Index()
        {
            InitializeComponent();
        }

        private void Index_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("¡OCURRIO UN ERROR! Contacte a soporte\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            con.Close();
        }

        private void txtUsuario_TextChanged(object sender, EventArgs e)
        {
            if (txtUsuario.Text.Trim() != string.Empty && txtUsuario.Text.All(char.IsLetter))
            {
                btnIngreso.Enabled = true;
                errorProvider1.SetError(txtUsuario, "");
            }
            else
            {
                if (!(txtUsuario.Text.All(char.IsLetter)))
                {
                    errorProvider1.SetError(txtUsuario, "El nombre de usuario solo debe contener letras");
                }
                else
                {
                    errorProvider1.SetError(txtUsuario, "Debe ingresar un nombre de usuario");
                }
                btnIngreso.Enabled = false;

            }
        }

        private void btnIngreso_Click(object sender, EventArgs e)
        {
            Boolean datosExistCon;
            Boolean datosExistNon;
            con.Open();
            String ConsultaCon = "select Contra from empleados where Contra='" + txtContra.Text + "';";
            MySqlCommand comandoCon = new MySqlCommand(ConsultaCon, con);
            MySqlDataReader lectoraCon;
            lectoraCon = comandoCon.ExecuteReader();
            if (lectoraCon.Read())
            {
                datosExistCon = lectoraCon.HasRows;
            }
            else
            {
                datosExistCon=false;
            }
            con.Close();

            con.Open();
            String ConsultaNom = "select Nombre from empleados where Nombre='" + txtUsuario.Text + "';";
            MySqlCommand comandoNom = new MySqlCommand(ConsultaNom, con);
            MySqlDataReader lectoraNon;
            lectoraNon = comandoNom.ExecuteReader();
            if (lectoraNon.Read())
            {
                datosExistNon = lectoraNon.HasRows;
            }
            else
            {
                datosExistNon=false;
            }
                con.Close();

            
            if (datosExistCon && datosExistNon)
            {
                MessageBox.Show("Bienvenido ", "Acceso comprobado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form ventanaDash = new Dashboard();
                ventanaDash.Show();
                //ventanaDash.ShowDialog();
                txtContra.Text = "";
                txtUsuario.Text = "";
                this.Visible=false;
            }
            else
            {
                MessageBox.Show("Compruebe sus credenciales y vuelva a intentarlo", "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtContra_TextChanged(object sender, EventArgs e)
        {
            if (txtContra.Text.Trim() != string.Empty && txtContra.Text.All(char.IsLetterOrDigit))
            {
                btnIngreso.Enabled = true;
                errorProvider1.SetError(txtContra, "");
            }
            else
            {
                if (!(txtContra.Text.All(char.IsLetterOrDigit)))
                {
                    errorProvider1.SetError(txtContra, "El nombre de usuario solo debe contener letras y numeros");
                }
                else
                {
                    errorProvider1.SetError(txtContra, "Debe ingresar una contraseña");
                }
                btnIngreso.Enabled = false;

            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void xbxHide_CheckedChanged(object sender, EventArgs e)
        {
            if (xbxHide.Checked==true)
            {
                if (txtContra.PasswordChar == '*')
                {
                    txtContra.PasswordChar = '\0';
                }
            }
            else
            {
                txtContra.PasswordChar = '*';
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            contador++;
            if (contador == 5)
            {
                MessageBox.Show("Haz encontrado uno de mis huevos de pascua!", "Easter egg", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Este programa fue creado con mucho amor por Ruben Silva, si te gusta recuerda valorarme positivamente! \nPara mas programas contactame al 3121534460", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
