﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace FinalProyect
{
    public partial class Eliminacion : Form
    {
        OleDbConnection con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\BD Mickey.accdb");
        public Eliminacion()
        {
            InitializeComponent();
        }

        
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form ventanaDash = new Dashboard();
            ventanaDash.Show();
            this.Close();
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            OleDbCommand buscar_comandoSQL;
            OleDbDataReader lector_datos;
            ListViewItem lista;
            int execute = 0;
            execute++;

            String buscar_sentenciaSQL;

            if ((rbtAproximada.Checked == false) && (rbtExacta.Checked == true))
            {
                try
                {
                    //BUSQUEDA EXACTA
                    buscar_sentenciaSQL = "SELECT * FROM Ventas WHERE Prenda='" + txtbusqueda.Text + "'";
                    
                    buscar_comandoSQL = new OleDbCommand(buscar_sentenciaSQL, con); //INSTRUCION SQL, CONEXION BASE DE DATOS

                    lector_datos = buscar_comandoSQL.ExecuteReader();


                    if (lector_datos.HasRows == true) //MOSTRAR REGISTROS
                    {
                        while (lector_datos.Read())
                        {

                            lista = new ListViewItem(lector_datos["Marca"].ToString());
                            lista.SubItems.Add(lector_datos["Modelo"].ToString());
                            lista.SubItems.Add(lector_datos["Prenda"].ToString());                //BUSQUEDA EXACTA
                            lista.SubItems.Add(lector_datos["Color"].ToString());
                            lista.SubItems.Add(lector_datos["Talla"].ToString());
                            lista.SubItems.Add(lector_datos["Cantidad"].ToString());
                            lista.SubItems.Add(lector_datos["Precio"].ToString());

                            listmostrar_registros.Items.Add(lista); //Observar la lista de productos
                        }
                        lbltotalregistros.Text = listmostrar_registros.Text = ("Total de Registros ->") + listmostrar_registros.Items.Count.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No se han encontrado datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    lector_datos.Close();


                }
                catch (Exception error)
                {
                    MessageBox.Show("¡OCURRIO UN ERROR! ---" + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            //--------------------------------------------------------------------------------------------------------------------------------------------------

            if (rbtAproximada.Checked == true && rbtExacta.Checked == false)
            {
                try
                {
                    //BUSQUEDA APROXIMADA
                    buscar_sentenciaSQL = "SELECT * FROM Ventas WHERE Prenda LIKE'" + txtbusqueda.Text + "%'";

                    buscar_comandoSQL = new OleDbCommand(buscar_sentenciaSQL, con); //INSTRUCION SQL, CONEXION BASE DE DATOS

                    lector_datos = buscar_comandoSQL.ExecuteReader();


                    if (lector_datos.HasRows == true) //MOSTRAR REGISTROS
                    {
                        while (lector_datos.Read())
                        {

                            lista = new ListViewItem(lector_datos["Marca"].ToString());
                            lista.SubItems.Add(lector_datos["Modelo"].ToString());
                            lista.SubItems.Add(lector_datos["Prenda"].ToString());                //BUSQUEDA APROXIMADA
                            lista.SubItems.Add(lector_datos["Color"].ToString());
                            lista.SubItems.Add(lector_datos["Talla"].ToString());
                            lista.SubItems.Add(lector_datos["Cantidad"].ToString());
                            lista.SubItems.Add(lector_datos["Precio"].ToString());

                            listmostrar_registros.Items.Add(lista); //Observar la lista de productos
                        }
                        lbltotalregistros.Text = listmostrar_registros.Text = ("Total de Registros ->") + listmostrar_registros.Items.Count.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No se han encontrado datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    lector_datos.Close();


                }
                catch (Exception error)
                {
                    MessageBox.Show("¡OCURRIO UN ERROR!---" + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                

            }
        }

        private void Eliminacion_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MessageBox.Show("Conexion Exitosa");
            }
            catch (Exception)
            {
                MessageBox.Show("Conexion Fallida");
            }

            listmostrar_registros.View = View.Details;
            listmostrar_registros.FullRowSelect = true;
            listmostrar_registros.GridLines = true;

            listmostrar_registros.Columns.Add("Marca", 57);
            listmostrar_registros.Columns.Add("Modelo", 80);
            listmostrar_registros.Columns.Add("Prenda", 80);
            listmostrar_registros.Columns.Add("Color", 80);
            listmostrar_registros.Columns.Add("Talla", 80);
            listmostrar_registros.Columns.Add("cantidad", 80);
            listmostrar_registros.Columns.Add("Precio", 70);


            btnbuscar.Enabled = false;
            btnborrar.Enabled = false;
        }

        private void bttonborrar_Click(object sender, EventArgs e)
        {
            foreach(ListViewItem lista in listmostrar_registros.SelectedItems)
            {
                DialogResult dialog = MessageBox.Show("¿Estas segur@ de eliminar esto?", "Borrar", MessageBoxButtons.YesNo);
                if(dialog==DialogResult.Yes)
                {
                    lista.Remove();
                    string eliminacion;
                    eliminacion = "Delete * FROM Ventas WHERE Modelo = '" + txtbusqueda.Text + "'";
                    OleDbCommand borrarsql;
                    OleDbDataReader borrar_p;

                    borrarsql = new OleDbCommand(eliminacion, con);
                    borrar_p = borrarsql.ExecuteReader();

                    
                    
                }

            }
        }

        private void listmostrar_registros_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listmostrar_registros.SelectedItems.Count > 0)
            {
                //MessageBox.Show(listmostrar_registros.SelectedItems[0].Text);
                txtbusqueda.Text = listmostrar_registros.SelectedItems[0].SubItems[1].Text;

            }
        }

        private void comprobacion()
          {
              if (txtbusqueda.Text.Trim() != string.Empty && txtbusqueda.Text.All(char.IsLetterOrDigit))
              {
                  btnbuscar.Enabled = true;
                  errorProvider1.SetError(txtbusqueda, "");
              }
              else
              {
                  if (!(txtbusqueda.Text.All(char.IsLetterOrDigit)))
                  {
                      errorProvider1.SetError(txtbusqueda, "");
                  }
                  else
                  {
                      errorProvider1.SetError(txtbusqueda, "Debe ingresar un indicio de busqueda");
                  }
                  btnbuscar.Enabled = false;
                  txtbusqueda.Focus();
              }
          }

        private void comprobacion1()
        {
            if (txtbusqueda.Text.Trim() != string.Empty && txtbusqueda.Text.All(char.IsLetterOrDigit))
            {
                btnborrar.Enabled = true;
                errorProvider2.SetError(btnborrar, "Debe seleccionar un articulo del inventario de la derecha y despues presionar 'Eliminar' para borrarlo del inventario");
            }
            else
            {
                if (!(txtbusqueda.Text.All(char.IsLetterOrDigit)))
                {
                    errorProvider1.SetError(txtbusqueda, "");
                }
                else
                {
                    errorProvider1.SetError(txtbusqueda, "Debe ingresar un indicio de busqueda");
                }
                btnborrar.Enabled = false;
                txtbusqueda.Focus();
            }
        }

        private void txtbusqueda_TextChanged(object sender, EventArgs e)
        {
            comprobacion();
            comprobacion1();

            if (txtbusqueda.Text.Trim() != string.Empty && txtbusqueda.Text.All(char.IsLetter))
            {
                btnbuscar.Enabled = true;
                errorProvider2.SetError(txtbusqueda, "");
            }
            else
            {
                if (!(txtbusqueda.Text.All(char.IsLetter)))

                {
                    errorProvider2.SetError(txtbusqueda, "El nombre del producto solo debe contener letras");
                }
                else
                {
                    errorProvider2.SetError(txtbusqueda, "Debe ingresar un producto");
                }
                btnbuscar.Enabled = false;

            }

            
        }

        private void Btnclean_Click(object sender, EventArgs e)
        {
                listmostrar_registros.Items.Clear();
                lbltotalregistros.Text = listmostrar_registros.Text = ("Total de Registros ->");
            
        }
    }
}
