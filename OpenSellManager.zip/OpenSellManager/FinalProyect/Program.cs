﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FinalProyect
{
    static class Program
    {

        public static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=disadb;UID=root;PASSWORD=;";
        public static MySqlConnection con = new MySqlConnection(conexion);
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Index());
        }
        
    }
}
