﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProyect
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {

            InitializeComponent();
        }

        public static implicit operator Menu(Dashboard v)
        {
            throw new NotImplementedException();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            Form ventanaSearch = new Search();
            ventanaSearch.Show();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form ventanaInput = new Ingresar();
            ventanaInput.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form ventanaUpdate = new Update();
            ventanaUpdate.Show();
            this.Close();
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            Form ventanaEliminacion = new Eliminacion();
            ventanaEliminacion.Show();
            this.Close();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            Form ventanaLogin = new Index();
            ventanaLogin.Show();
            this.Close();
        }
    }
    
}
