﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FinalProyect
{
    public partial class Update : Form
    {

        static string conexion = "SERVER=127.0.0.1;PORT=3306;DATABASE=disadb;UID=root;PASSWORD=;";
        MySqlConnection con = new MySqlConnection(conexion);
        public Update()
        {
            InitializeComponent();
        }

        private void Update_Load_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                //MessageBox.Show("Conexion Exitosa");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("¡OCURRIO UN ERROR! Contacte a soporte\n" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            listmostrar_registros.View = View.Details;
            listmostrar_registros.FullRowSelect = true;
            listmostrar_registros.GridLines = true;

            listmostrar_registros.Columns.Add("Producto", 120);
            listmostrar_registros.Columns.Add("Tipo", 80);
            listmostrar_registros.Columns.Add("Precio de compra", 100);
            listmostrar_registros.Columns.Add("Precio de venta", 100);
            listmostrar_registros.Columns.Add("Cantidad", 80);
            listmostrar_registros.Columns.Add("SKU", 0);
        }
        private void obtener()
        {
            txtNombre.Text = listmostrar_registros.SelectedItems[0].SubItems[0].Text;
            txtTipo.Text = listmostrar_registros.SelectedItems[0].SubItems[1].Text;
            txtPrecio.Text = listmostrar_registros.SelectedItems[0].SubItems[2].Text;
            txtCantidad.Text = listmostrar_registros.SelectedItems[0].SubItems[4].Text;
            txtCodigo.Text = listmostrar_registros.SelectedItems[0].SubItems[5].Text;
        }

        private void buscar()
        {
            listmostrar_registros.Items.Clear();
            MySqlDataReader lector_datos;
            String buscar_sentenciaSQL = "SELECT * FROM productos WHERE Nombre LIKE'" + txtbusqueda.Text + "%'"; ;
            MySqlCommand buscar_comandoSQL = new MySqlCommand(buscar_sentenciaSQL, con);

            try
            {
                con.Open();
                lector_datos = buscar_comandoSQL.ExecuteReader();


                if (lector_datos.HasRows == true) //MOSTRAR REGISTROS
                {
                    while (lector_datos.Read())
                    {

                        ListViewItem lista = new ListViewItem(lector_datos["Nombre"].ToString());
                        lista.SubItems.Add(lector_datos["Tipo"].ToString());
                        lista.SubItems.Add(lector_datos["PrecioC"].ToString());                //BUSQUEDA APROXIMADA
                        lista.SubItems.Add(lector_datos["PrecioV"].ToString());
                        lista.SubItems.Add(lector_datos["Cantidad"].ToString());
                        lista.SubItems.Add(lector_datos["SKU"].ToString());

                        listmostrar_registros.Items.Add(lista); //Observar la lista de productos
                    }
                }
                else
                {
                    MessageBox.Show("No se han encontrado datos", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                lector_datos.Close();

                if (txtbusqueda.Text == String.Empty)
                {
                    listmostrar_registros.Items.Clear();
                }
                con.Close();

            }
            catch (Exception error)
            {
                MessageBox.Show("¡OCURRIO UN ERROR!---" + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        string SKU;
        

        private void btnSent_Click(object sender, EventArgs e)
        {
            string precio = txtPrecio.Text;
            double PrecioC = float.Parse(precio);
            double PrecioV = PrecioC + (PrecioC * .16);
            PrecioV = PrecioV + (PrecioV * .30);
            MySqlCommand comandoInsert;
            MySqlDataReader actualizar;
            string comando = "UPDATE productos SET SKU = '" + txtCodigo.Text + "', Nombre= '" + txtNombre.Text + "', PrecioC = '" + txtPrecio.Text + "', PrecioV = '" + PrecioV + "', Cantidad = '" + txtCantidad.Text + "', Tipo = '" + txtTipo.Text + "' WHERE SKU = '" + SKU + "';";


            try
            {
                con.Open();
                comandoInsert = new MySqlCommand(comando, con);
                actualizar = comandoInsert.ExecuteReader();

                MessageBox.Show("Los datos se han enviado correctamente", "Sucesfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception error)
            {
                MessageBox.Show("¡OCURRIO UN ERROR!---" + error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();
            buscar();
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            Form ventanaDash = new Dashboard();
            ventanaDash.Show();
            this.Close();
        }

        private void listmostrar_registros_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (listmostrar_registros.SelectedItems.Count > 0)
            {
                obtener();
                SKU = listmostrar_registros.SelectedItems[0].SubItems[5].Text;
            }
        }

        private void txtbusqueda_TextChanged(object sender, EventArgs e)
        {
            buscar();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            listmostrar_registros.Items.Clear();
        }
    }
}
